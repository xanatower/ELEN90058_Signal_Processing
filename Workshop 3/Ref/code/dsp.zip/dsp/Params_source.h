
// TODO: 0. Modify these constants to match the filter you have designed

// length of filter
#define M 1

// buffer size
#define N 64

// input data processing block size
#define L (N-M+1)
